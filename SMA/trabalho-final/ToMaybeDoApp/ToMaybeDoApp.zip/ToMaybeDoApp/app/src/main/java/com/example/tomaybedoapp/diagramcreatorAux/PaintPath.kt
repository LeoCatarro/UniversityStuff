package com.example.tomaybedoapp.diagramcreatorAux

import android.graphics.Path


class PaintPath(var path : Path) {
}