package galapaxos;

import java.awt.Graphics;

interface DrawingController {
    void redraw(Graphics var1);

    void setCanvas(DrawingCanvas var1);
}
