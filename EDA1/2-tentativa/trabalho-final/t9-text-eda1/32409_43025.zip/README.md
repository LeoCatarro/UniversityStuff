

# Compile Line
* gcc -std=c99 -Wall hashtable_words.c hashtable_keys.c MCurtas.c -o MCurtas -lm

# Run line
* ./MCurtas "dicionario.txt"

## Notas:
* Garanta que o dicionário está presente na pasta dictonaries
