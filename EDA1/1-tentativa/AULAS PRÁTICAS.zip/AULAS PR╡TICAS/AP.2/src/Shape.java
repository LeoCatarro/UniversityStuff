public abstract class Shape {
    protected double area;

}
