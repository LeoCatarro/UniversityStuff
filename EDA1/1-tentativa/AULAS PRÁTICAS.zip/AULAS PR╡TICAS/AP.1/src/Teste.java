public class Teste {
    public static void main(String[] args) {
        Fracao fracA = new Fracao();
        Fracao fracB = new Fracao(2);
        Fracao fracC = new Fracao(6, 4);

        System.out.println(fracA);
        System.out.println(fracB);
        fracC.reduce();
        System.out.println(fracC);
    }
}
