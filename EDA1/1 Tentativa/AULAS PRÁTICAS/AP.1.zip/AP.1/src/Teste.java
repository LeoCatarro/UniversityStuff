public class Teste {
    public static void main(String[] args) {
        Fracao fracA = new Fracao();
        Fracao fracB = new Fracao( 2);
        Fracao fracC = new Fracao( 4, 6);

        System.out.println(fracA);
        System.out.println(fracB);
        System.out.println(fracC);
    }
}
