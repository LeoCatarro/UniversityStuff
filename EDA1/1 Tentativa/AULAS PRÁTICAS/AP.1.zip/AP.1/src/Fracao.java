//1)
//1.1)
class Fracao {
    public int numerador;
    public int denominador;


    //Construtor vazio
    public Fracao() {
        this.numerador = 0;
        this.denominador = 1;
    }

    //Construtor que recebe 1 parametro
    public Fracao(int m) {
        this.numerador = m;
    }

    //Construtor que recebe os 2 parametros
    public Fracao(int n, int d) {
        this.numerador = n;
        this.denominador = d;
    }

    //1.3)
    //Getter e Setter
    public int getNumerador() {
        return numerador;
    }

    public void setNumerador(int numerador) {
        this.numerador = numerador;
    }

    public int getDenominador() {
        return denominador;
    }

    public void setDenominador(int denominador) {
        this.denominador = denominador;
    }

    //1.4)
    public String toString() {
        return (numerador + "/" + denominador);
    }

    //1.5)
    public int reduce() {
        int novoNumerador, novoDenominador;
        if (numerador > denominador) {
            for (int i = 2; i <= denominador; i++) {
                if (numerador % i == 0 && denominador % i == 0) {
                    novoNumerador = numerador / i;
                    novoDenominador = denominador / i;
                }
            }
        } else if (numerador < denominador) {
            for (int i = 2; i <= numerador; i++) {
                if (numerador % i == 0 && denominador % i == 0) {
                    novoNumerador = numerador / i;
                    novoDenominador = denominador / i;
                }
            }
        }

}