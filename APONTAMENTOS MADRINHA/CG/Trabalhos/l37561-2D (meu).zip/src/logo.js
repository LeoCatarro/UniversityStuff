	

function QuadradoFundo (c2d) {

	c2d.beginPath();
    	
    	//Desenho do esqueleto do logotipo
	    c2d.moveTo(0, 0);
		c2d.moveTo(100, 30);           
		c2d.arcTo(470, 30, 470, 100, 90);
		c2d.arcTo(470, 465, 400, 470, 90);
		c2d.arcTo(30, 470, 30, 100, 90);
		c2d.arcTo(30, 30, 100, 30, 90);

		//Criação do Gradiente: A crição do gradiente semelhante ao da imagem não foi possivel
		var grd = c2d.createLinearGradient(0, 0, 0, 470);

		grd.addColorStop("0.1", "#515bd4");
		grd.addColorStop("0.2", "#8134af");
		grd.addColorStop("0.6", "#dd2a7b");
		grd.addColorStop("0.8", "#f58529");
		grd.addColorStop("1.0", "#feda77");

		//Preencher o esqueleto do logotipo c/ o gradiente
		c2d.fillStyle = grd;
		c2d.fill();

		//Criação de uma sombra 
		c2d.shadowColor = "pink";

	c2d.closePath();

}

function QuadradoInterior (c2d) {

	c2d.beginPath();

		//Desenho do quadrado interior
		c2d.moveTo(180, 100);
		c2d.arcTo(400, 100, 400, 400, 70);
		c2d.arcTo(400, 400, 300, 400, 70);
		c2d.arcTo(105, 400, 105, 100, 70);
		c2d.arcTo(105, 100, 115, 100, 70);

		c2d.lineWidth = 30;
		c2d.lineCap = "round";
		c2d.strokeStyle = "white";
		c2d.stroke();
	
	c2d.closePath();
}

function CirculoPequeno (c2d, x, y) {

	c2d.beginPath();

		//Desenho do Circulo pequeno e o seu preenchimento
		c2d.arc(x, y, 4, 0, 2 * Math.PI);

		c2d.lineWidth = 30;
		c2d.strokeStyle = "white";
		c2d.stroke();

		c2d.fillStyle = "white";
		c2d.fill();
	
	c2d.closePath();	
}

function CirculoGrande (c2d, circleColor) {

	c2d.beginPath();

		//Desenho do circulo do meio
		c2d.arc(255, 250, 70, 0, 2* Math.PI);

		c2d.lineWidth = 30;
		c2d.strokeStyle = circleColor;
		c2d.shadowColor = "pink";

		c2d.stroke();

	c2d.closePath();

}

function Quadrados(c2d) {

	QuadradoFundo(c2d);
	QuadradoInterior(c2d);
	
}

function animation_CircP(c2d, x, y){

	setInterval(function(){ 
		
		if (y <= 355 && x == 345){
			c2d.clearRect(0,0,500,500);
	  		Quadrados(c2d);
	  		CirculoPequeno(c2d, x, y);
	  		y+=5;
		}
	}, 5);

	setInterval(function(){

		if (y == 355 && x >= 160){
			c2d.clearRect(0,0,500,500);
	  		Quadrados(c2d);
	  		CirculoPequeno(c2d, x, y);
	  		x -= 5;
		}
	});

	setInterval(function(){

		if (y >= 150 && x == 160){
			c2d.clearRect(0,0,500,500);
	  		Quadrados(c2d);
	  		CirculoPequeno(c2d, x, y);
	  		y -= 5;
		}
	});

	setInterval(function(){

		if (y == 150 && x <= 345){
			c2d.clearRect(0,0,500,500);
	  		Quadrados(c2d);
	  		CirculoPequeno(c2d, x, y);
	  		x += 5;
		}
	});

}

function animation_CircG(c2d, colorArray){


	setInterval(function() {

	  	let circleColor = colorArray [Math.floor(Math.random() * 5 + 1)];
	  	CirculoGrande(c2d, circleColor);

	}, 5);

}

function main () {

	var c2d = document.getElementById("acanvas").getContext("2d");
	Quadrados(c2d);

	var y = 160;
	var x = 345;
	
	var colorArray = ["#515bd4", "#8134af", "#dd2a7b", "#f58529", "#feda77"];

	animation_CircP(c2d, x, y);
	animation_CircG(c2d, colorArray);

}