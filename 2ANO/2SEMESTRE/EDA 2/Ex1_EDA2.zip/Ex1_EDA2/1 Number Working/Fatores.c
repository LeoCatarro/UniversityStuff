#include <stdio.h>

int PrimeFactors(int n){
	int num=2;
	int count=0;

	while(n > 1){
		if(n % num == 0){
			n = n/num;
			count++;
		}
		else{
			num++;
		}
	}
	return count;
}

int main(){
	int n, res;

	printf("Entrada:\n");
	scanf("%d", &n);

	res = PrimeFactors(n);
	printf("%d : %d", n, res);
	
	return 0;
}