//EXERCICIO FEITO FUNCIONANDO!!!

#include <stdio.h>

int PrimeFactors(int n){
	int num=2;
	int count=0;

	while(n > 1){
		if(n % num == 0){
			n = n/num;
			count++;
		}
		else{
			num++;
		}
	}
	return count;
}

int main(){	

	FILE *file;
	int number;

	file = fopen("entrada.txt" , "r");
	
	while(fscanf(file, "%d", &number) != EOF){
		printf("%d: %d\n", number, PrimeFactors(number)); 
    }
    fclose(file);	
	return 0;
}
	
	



