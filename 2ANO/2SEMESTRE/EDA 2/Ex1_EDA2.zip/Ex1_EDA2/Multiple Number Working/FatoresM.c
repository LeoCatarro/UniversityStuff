#include <stdio.h>

int PrimeFactors(int n){
	int num=2;
	int count=0;

	while(n > 1){
		if(n % num == 0){
			n = n/num;
			count++;
		}
		else{
			num++;
		}
	}
	return count;
}

int main(){
	int i=0, n, res;
	//Guarda os diversos valores de entrada
	int input[1000];

	printf("Entrada:\n");

	for(int j=0 ; j<1000 ; j++){
		while(input[i] != '\n'){	
			scanf("%d", &n);
			if(input[i] == ' '){
				PrimeFactors(n);
				printf("\n");
			}
			res = PrimeFactors(n);
			printf("%d: %d", n, res);
			printf("\n");	
		}
		break;
		i++;
	}
	return 0;
}