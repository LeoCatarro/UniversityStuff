//Função para tocar o audio ao clicar na campainha

var x = document.getElementById("myAudio"); 

function playAudio() 
{ 
    x.play(); 
} 

