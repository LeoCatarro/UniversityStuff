
public interface IPawn {
    void movePawn(String Move); // changes this pawn position according to move.
    Route getRoute(); // returns the current route.
}